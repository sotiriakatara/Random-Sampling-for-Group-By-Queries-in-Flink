package Producer.ECE6221;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;




//Create java class named âSimpleProducerâ
public class SimpleProducer {

	public static void main(String[] args) throws Exception {
		

		// Assign topicName to string variable
		String topicName = "testSource";
		// create instance for properties to access producer configs
		Properties props = new Properties();
		// Assign localhost id
		props.put("bootstrap.servers", "localhost:9092");
		// Set acknowledgements for producer requests.
		props.put("acks", "all");
		// If the request fails, the producer can automatically retry,
		props.put("retries", 0);
		// Specify buffer size in config
		props.put("batch.size", 16384);

		// Reduce the no of requests less than 0
		props.put("linger.ms", 0);

		// The buffer.memory controls the total amount of memory available to the
		// producer for buffering.
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		Producer<String, String> producer = new KafkaProducer<String, String>(props);

		BufferedReader br = new BufferedReader(new FileReader("openaq.csv"));
		String line = br.readLine();
		line = null;	
		while ((line = br.readLine()) != null) {
		
			System.out.println(line);
			String[] words = line.split(",");
			
			String concat = words[5].concat(";").concat(words[6]);
			//System.out.println(new ProducerRecord<String, String>(topicName, words[5], concat));
			producer.send(new ProducerRecord<String, String>(topicName, words[5], concat));
		}

		br.close();
		producer.close();

	}
}
