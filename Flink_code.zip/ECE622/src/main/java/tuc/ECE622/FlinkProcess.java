package tuc.ECE622;
import java.util.ArrayList;

import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;

import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.sampling.IntermediateSampleData;

import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessAllWindowFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;

import org.apache.flink.util.Collector;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import tuc.ECE622.sources.kafkaConsumer;
import tuc.ECE622.sources.kafkaProducer2;

public class FlinkProcess {

	static double globalSum = 0.0;
	static List<Double> sList = new ArrayList<Double>();

	public static void main(String[] args) throws Exception {
		for(int i = 0; i < 2; i++) {
			Random random = new Random();
			sList.add((double) random.nextInt(10));
		}
		// set up the execution environment
		final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment().setParallelism(2);

		// using KafkaTopics as Source and Sink
		String kafkaDataInputTopic = "testSource";
		String kafkaBrokersList = "localhost:9092";
		String kafkaOutputTopic = "testSink";

		// build a copy of kafkaConsumer
		kafkaConsumer kc = new kafkaConsumer(kafkaBrokersList, kafkaDataInputTopic);
		// build a copy of KafkaProducer
		kafkaProducer2 kp = new kafkaProducer2(kafkaBrokersList, kafkaOutputTopic);

		/// ---- Datastream convert to string----

		DataStream<String> input = env.addSource(kc.getFc());// data read from kafka
		// map kafka data input to DataStream<String>

		// Take in pairs (key, value)
		DataStream<Tuple2<String, Double>> tokenizedInput = input.flatMap(new Tokenizer());

		// Process For Calculation of Mean Values
		DataStream<Tuple2<String, Double>> meanKeyValues = tokenizedInput.keyBy(0).timeWindow(Time.seconds(10))
				.aggregate(new AverageAggregate(), new MyProcessWindowFunction());

		// Process For Calculation of Variance Values
		DataStream<Tuple2<String, Double>> squaredKeyValues = tokenizedInput.flatMap(new SquaredFunction());
		DataStream<Tuple2<String, Double>> meanSquaredKeyValues = squaredKeyValues.keyBy(0).timeWindow(Time.seconds(10))
				.aggregate(new AverageAggregate(), new MyProcessWindowFunction());

		DataStream<Tuple2<String, Double>> squaredMeanKeyValues = meanKeyValues.flatMap(new SquaredFunction());
		meanKeyValues.print("Mean Values");

		DataStream<Tuple2<String, Double>> varianceKeyValues = meanSquaredKeyValues.union(squaredMeanKeyValues).keyBy(0)
				.timeWindow(Time.seconds(10)).reduce(new VarianceFunction());

		DataStream<Tuple2<String, Double>> standardDeviation = varianceKeyValues.flatMap(new RootFunction());
		standardDeviation.print("Standard Deviation");

		DataStream<Tuple2<String, Double>> unitedDevMean = standardDeviation.union(meanKeyValues);

		DataStream<Tuple2<String, Double>> gamma = unitedDevMean.keyBy(0).timeWindow(Time.seconds(30))
				.reduce(new GammaFunction());
		//gamma.print("Gamma");
		DataStream<Tuple2<String, Double>> gammaSum = gamma.timeWindowAll(Time.seconds(25)).process(new sumFunction());

		DataStream<Tuple2<String, Double>> final1 = gamma.union(gammaSum).keyBy(1).timeWindowAll(Time.seconds(20))
				.process(new myFunction());
		//final1.print("Si");
		final1.keyBy(1).timeWindowAll(Time.seconds(20)).process(new procSi()).print("Floor");
		

		// Sampling
    	DataStream<Tuple2<String, Double>> secondPhase = tokenizedInput.keyBy(0).timeWindowAll(Time.seconds(30))
				.process(new SamplingFunction());

		secondPhase.print("Sample");

		secondPhase.addSink(kp.getProducer()); // write to kafka
		// execute program
		env.execute("Streaming WordCount");
		

	}

	// *************************************************************************
	// USER FUNCTIONS
	// *************************************************************************

	/**
	 * Implements the string tokenizer that splits sentences into words as a
	 * user-defined FlatMapFunction. The function takes a line (String) and splits
	 * it into multiple pairs in the form of "(word,1)" ({@code Tuple2<String,
	 * Integer>}).
	 */
	public static class procSi
			extends ProcessAllWindowFunction<Tuple2<String, Double>, Tuple2<String, Double>, TimeWindow> {

		private static final long serialVersionUID = 1L;
		Double numOfSam = 0.0;
		public void process(Context context, Iterable<Tuple2<String, Double>> input,
				Collector<Tuple2<String, Double>> out) {
			
			for (Tuple2<String, Double> in : input) {
				numOfSam = Math.floor(in.f1);
				sList.add(numOfSam);				
				//out.collect(new Tuple2<String, Double>(in.f0, numOfSam));
			}
		}

	}

	public static class myFunction
			extends ProcessAllWindowFunction<Tuple2<String, Double>, Tuple2<String, Double>, TimeWindow> {

		private static final long serialVersionUID = 1L;

		public void process(Context context, Iterable<Tuple2<String, Double>> input,
				Collector<Tuple2<String, Double>> out) {

			Double gam = 0.0;
			for (Tuple2<String, Double> in : input) {
				if (in.f0.equals("gamma")) {
					gam = in.f1;
					continue;
				}
			}
			for (Tuple2<String, Double> in1 : input) {
				if (in1.f0 != "gamma") {
					out.collect(new Tuple2<String, Double>(in1.f0, in1.f1 / 1.23 * 10));
				}
			}

		}

	}

	public static final class Tokenizer implements FlatMapFunction<String, Tuple2<String, Double>> {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public void flatMap(String value, Collector<Tuple2<String, Double>> out) {
			// normalize and split the line
			// System.out.println(value);
			String[] tokens = value.split(";");
			/*
			 * for(int i = 0; i < tokens.length ; i++) { System.out.println(tokens[i]); }
			 */
			// emit the pairs
			if (tokens.length > 1)
				out.collect(new Tuple2<>(tokens[0], Double.parseDouble(tokens[1])));

		}

	}

	private static class AverageAggregate
			implements AggregateFunction<Tuple2<String, Double>, Tuple2<Double, Double>, Double> {

		private static final long serialVersionUID = 1L;

		@Override
		public Tuple2<Double, Double> createAccumulator() {
			return new Tuple2<>(0.0, 0.0);
		}

		@Override
		public Tuple2<Double, Double> add(Tuple2<String, Double> value, Tuple2<Double, Double> accumulator) {
			return new Tuple2<>(accumulator.f0 + value.f1, accumulator.f1 + 1L);
		}

		@Override
		public Double getResult(Tuple2<Double, Double> accumulator) {
			return ((double) accumulator.f0) / accumulator.f1;
		}

		@Override
		public Tuple2<Double, Double> merge(Tuple2<Double, Double> a, Tuple2<Double, Double> b) {
			return new Tuple2<>(a.f0 + b.f0, a.f1 + b.f1);
		}
	}

	private static class MyProcessWindowFunction
			extends ProcessWindowFunction<Double, Tuple2<String, Double>, Tuple, TimeWindow> {

		private static final long serialVersionUID = 1L;

		public void process(Tuple key, Context context, Iterable<Double> averages,
				Collector<Tuple2<String, Double>> out) {
			// context: keeps metadata of window
			Double average = averages.iterator().next();
			out.collect(new Tuple2<>(key.toString(), average));
		}
	}

	public static final class SquaredFunction
			implements FlatMapFunction<Tuple2<String, Double>, Tuple2<String, Double>> {

		private static final long serialVersionUID = 1L;

		@Override
		public void flatMap(Tuple2<String, Double> value, Collector<Tuple2<String, Double>> out) {
			// normalize and split the line
			out.collect(new Tuple2<>(value.f0, value.f1 * value.f1));
		}
	}

	public static final class RootFunction implements FlatMapFunction<Tuple2<String, Double>, Tuple2<String, Double>> {

		private static final long serialVersionUID = 1L;

		@Override
		public void flatMap(Tuple2<String, Double> value, Collector<Tuple2<String, Double>> out) {
			// normalize and split the line
			out.collect(new Tuple2<>(value.f0, Math.sqrt(value.f1)));
		}
	}

	public static final class VarianceFunction implements ReduceFunction<Tuple2<String, Double>> {

		private static final long serialVersionUID = 1L;

		@Override
		public Tuple2<String, Double> reduce(Tuple2<String, Double> value1, Tuple2<String, Double> value2) {
			// normalize and split the line
			if (value1.f1 >= value2.f1) {
				return new Tuple2<String, Double>(value1.f0, value1.f1 - value2.f1);
			} else
				return new Tuple2<String, Double>(value1.f0, value2.f1 - value1.f1);
		}
	}

	public static final class GammaFunction implements ReduceFunction<Tuple2<String, Double>> {

		private static final long serialVersionUID = 1L;

		@Override
		public Tuple2<String, Double> reduce(Tuple2<String, Double> value1, Tuple2<String, Double> value2) {
			// normalize and split the line

			return new Tuple2<String, Double>(value1.f0, 1 / (value1.f1 / value2.f1));

		}
	}

	public static class sumFunction
			extends ProcessAllWindowFunction<Tuple2<String, Double>, Tuple2<String, Double>, TimeWindow> {

		private static final long serialVersionUID = 1L;

		public void process(Context context, Iterable<Tuple2<String, Double>> input,
				Collector<Tuple2<String, Double>> out) {
			Double sum = 0.0;
			for (Tuple2<String, Double> in : input) {
				sum = sum + in.f1;
				
			}
			out.collect(new Tuple2<String, Double>("gamma", sum));
		}
	}

	public static final class Deviation implements MapFunction<Tuple, Tuple> {

		private static final long serialVersionUID = 1L;

		@Override
		public Tuple map(Tuple value) throws Exception {
			// TODO Auto-generated method stub
			value.getField(0);
			return value;
		}
	}

	public static final class DivisionSGFunction
			implements FlatMapFunction<Tuple2<String, Double>, Tuple2<String, Double>> {

		private static final long serialVersionUID = 1L;

		@Override
		public void flatMap(Tuple2<String, Double> value, Collector<Tuple2<String, Double>> out) {
			// normalize and split the line
			// System.out.println(gammaList.get(gammaList.size()));
			out.collect(new Tuple2<>(value.f0, ((value.f1 / 1.23) * 10)));
		}
	}

	public static class SamplingFunction
			extends ProcessAllWindowFunction<Tuple2<String, Double>, Tuple2<String, Double>, TimeWindow> {

		private static final long serialVersionUID = 1L;
		private final Random random = new Random();
		private int numOfSamples = 0;

		public void process(Context context, Iterable<Tuple2<String, Double>> input,
				Collector<Tuple2<String, Double>> out) {
			
			for(int i = 0; i < (sList.size()); i++) {
				
				PriorityQueue<IntermediateSampleData<Tuple2<String, Double>>> queue = new PriorityQueue<IntermediateSampleData<Tuple2<String, Double>>>(
						sList.get(i).intValue());
				int index = 0;
				
				IntermediateSampleData<Tuple2<String, Double>> smallest = null;
				for (Tuple2<String, Double> in : input) {
					Tuple2<String, Double> element = in;
					if (index < sList.get(i).intValue()) {
						// Fill the queue with first K elements from input.
						queue.add(new IntermediateSampleData<Tuple2<String, Double>>(random.nextDouble(), element));
		
						out.collect(new Tuple2<>(element.f0, element.f1));
						numOfSamples++;
						smallest = queue.peek();
					} else {
						double rand = random.nextDouble();
						// Remove the element with the smallest weight, and append current element into
						// the queue.
						if (rand > smallest.getWeight()) {
							queue.remove();
							queue.add(new IntermediateSampleData<Tuple2<String, Double>>(rand, element));
							out.collect(new Tuple2<>(element.f0, element.f1));
							numOfSamples++;
							smallest = queue.peek();
						}
					}
					index++;
				}
					System.out.println("Numder of Samples is: " + numOfSamples);
				}
			}
	}

}
